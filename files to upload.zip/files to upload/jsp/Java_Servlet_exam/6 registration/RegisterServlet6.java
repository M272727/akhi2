package question6;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class RegisterServlet6
 */
@WebServlet("/RegisterServlet6")
public class RegisterServlet6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    // JDBC Config
    String jdbcURL = "jdbc:mysql://localhost:3306/registration_db";
    String jdbcUsername = "root";
    String jdbcPassword = "R150903@m";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet6() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		  // Step 1: Get form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");

        // Step 2: Save data to DB
        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to DB
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Prepare SQL statement
            String sql = "INSERT INTO users (name, email, password, gender) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setString(4, gender);

            int row = stmt.executeUpdate();

            // If insert successful, forward to confirmation.jsp
            if (row > 0) {
                request.setAttribute("username", name);
                request.getRequestDispatcher("confirmation.jsp").forward(request, response);
            } else {
                response.getWriter().println("Registration failed!");
            }

            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
	}


