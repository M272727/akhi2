package handson9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;

public class AttendanceSystem extends JFrame {
    private JComboBox<String> studentComboBox;
    private JTextField dateField;
    private JComboBox<String> statusComboBox;
    private JTable attendanceTable;
    private DefaultTableModel tableModel;

    public AttendanceSystem() {
        setTitle("Attendance System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top Panel
        JPanel topPanel = new JPanel(new FlowLayout());
        studentComboBox = new JComboBox<>();
        dateField = new JTextField(10);
        statusComboBox = new JComboBox<>(new String[]{"Present", "Absent"});
        JButton markButton = new JButton("Mark Attendance");

        topPanel.add(new JLabel("Student:"));
        topPanel.add(studentComboBox);
        topPanel.add(new JLabel("Date (YYYY-MM-DD):"));
        topPanel.add(dateField);
        topPanel.add(new JLabel("Status:"));
        topPanel.add(statusComboBox);
        topPanel.add(markButton);

        add(topPanel, BorderLayout.NORTH);

        // Table for displaying attendance
        tableModel = new DefaultTableModel(new Object[]{"ID", "Student", "Date", "Status"}, 0);
        attendanceTable = new JTable(tableModel);
        add(new JScrollPane(attendanceTable), BorderLayout.CENTER);

        // Mark Attendance Action
        markButton.addActionListener(this::markAttendance);

        // Load Data
        loadStudents();
        loadAttendance();
    }

    private void markAttendance(ActionEvent e) {
        String student = (String) studentComboBox.getSelectedItem();
        String[] studentDetails = student.split(" - ");
        String studentId = studentDetails[0];
        String date = dateField.getText().trim();
        String status = (String) statusComboBox.getSelectedItem();

        if (date.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the date.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = getConnection()) {
            String query = "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(studentId));
            pstmt.setString(2, date);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Attendance marked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            loadAttendance();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error marking attendance: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStudents() {
        studentComboBox.removeAllItems();
        try (Connection conn = getConnection()) {
            String query = "SELECT id, name FROM students";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                studentComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading students: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadAttendance() {
        tableModel.setRowCount(0);
        try (Connection conn = getConnection()) {
            String query = "SELECT a.id, s.name, a.date, a.status FROM attendance a JOIN students s ON a.student_id = s.id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDate("date"),
                        rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading attendance: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/YourDatabaseName", "root", "0000");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AttendanceSystem frame = new AttendanceSystem();
            frame.setVisible(true);
        });
    }
}
