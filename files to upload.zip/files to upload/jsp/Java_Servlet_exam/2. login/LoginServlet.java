package question2;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC details
    String jdbcURL = "jdbc:mysql://localhost:3306/logindb";
    String jdbcUsername = "root"; // default XAMPP username
    String jdbcPassword = "R150903@m";     // default XAMPP password (empty)

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Step 1: Get values from form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Step 2: Initialize JDBC
        try {
            // Load JDBC driver (optional in newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 3: Connect to database
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Step 4: Prepare SQL query to check user
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);

            // Step 5: Execute query
            ResultSet rs = stmt.executeQuery();

            // Step 6: Check if user exists
            if (rs.next()) {
                // User found - login successful
                response.sendRedirect("welcome.jsp");
            } else {
                // Invalid login
                response.sendRedirect("login.jsp?error=true");
            }

            // Step 7: Close everything
            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
}
