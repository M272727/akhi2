package swingApplication;
import javax.swing.*;

public class SwingDemo {
	
	public SwingDemo() {
		JFrame jFrame = new JFrame();
		
		jFrame.setTitle("Welcome Jframe");
		jFrame.setLayout(null);
		jFrame.setSize(400,400);
		jFrame.setVisible(true);

	}
}